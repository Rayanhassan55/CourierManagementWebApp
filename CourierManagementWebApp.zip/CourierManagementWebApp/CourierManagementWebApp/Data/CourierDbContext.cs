﻿using CourierManagementWebApp.Models;
using Microsoft.EntityFrameworkCore;

namespace CourierManagementWebApp.Data
{
    public class CourierDbContext : DbContext
    {
        

        public CourierDbContext(DbContextOptions options) : base(options)
        {
        }
        public DbSet<Courier>  T_Courier { get; set; }
        public DbSet<Customer> T_Customer { get; set; }
        public DbSet<Shipment> T_Shipment { get; set; }
        public DbSet<Address>  T_Address { get; set; }
        public DbSet<Payment>  T_Payment { get; set; }
        public DbSet<SignUp> SignUps { get; set; }
        public DbSet<SignIn> SignIns { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Payment>()
        .Property(p => p.Amount)
        .HasColumnType("decimal(18, 4)");  // Adjust precision and scale as needed

            modelBuilder.Entity<Shipment>().HasOne(s => s.Courier).WithMany(c => c.Shipments).HasForeignKey(s => s.CourierId);
            modelBuilder.Entity<Shipment>().HasOne(s => s.Customer).WithMany(c => c.Shipments).HasForeignKey(s => s.CustomerId);
            modelBuilder.Entity<Shipment>().HasOne(s => s.Address).WithMany(c => c.Shipments).HasForeignKey(s => s.AddressId);
        }
    }
}

