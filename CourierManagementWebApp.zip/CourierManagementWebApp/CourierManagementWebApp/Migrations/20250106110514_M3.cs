﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CourierManagementWebApp.Migrations
{
    /// <inheritdoc />
    public partial class M3 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "T_Address",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    StreetAddress = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    City = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    State = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ZIPCode = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Country = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_T_Address", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "T_Customer",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_T_Customer", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "T_Shipment",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CourierId = table.Column<int>(type: "int", nullable: false),
                    CustomerId = table.Column<int>(type: "int", nullable: false),
                    AddressId = table.Column<int>(type: "int", nullable: false),
                    ShipmentDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Status = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_T_Shipment", x => x.Id);
                    table.ForeignKey(
                        name: "FK_T_Shipment_T_Address_AddressId",
                        column: x => x.AddressId,
                        principalTable: "T_Address",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_T_Shipment_T_Courier_CourierId",
                        column: x => x.CourierId,
                        principalTable: "T_Courier",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_T_Shipment_T_Customer_CustomerId",
                        column: x => x.CustomerId,
                        principalTable: "T_Customer",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "T_Payment",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ShipmentId = table.Column<int>(type: "int", nullable: false),
                    Amount = table.Column<decimal>(type: "decimal(18,4)", nullable: false),
                    paymentDate = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_T_Payment", x => x.Id);
                    table.ForeignKey(
                        name: "FK_T_Payment_T_Shipment_ShipmentId",
                        column: x => x.ShipmentId,
                        principalTable: "T_Shipment",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_T_Payment_ShipmentId",
                table: "T_Payment",
                column: "ShipmentId");

            migrationBuilder.CreateIndex(
                name: "IX_T_Shipment_AddressId",
                table: "T_Shipment",
                column: "AddressId");

            migrationBuilder.CreateIndex(
                name: "IX_T_Shipment_CourierId",
                table: "T_Shipment",
                column: "CourierId");

            migrationBuilder.CreateIndex(
                name: "IX_T_Shipment_CustomerId",
                table: "T_Shipment",
                column: "CustomerId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "T_Payment");

            migrationBuilder.DropTable(
                name: "T_Shipment");

            migrationBuilder.DropTable(
                name: "T_Address");

            migrationBuilder.DropTable(
                name: "T_Customer");
        }
    }
}
