

document.addEventListener('DOMContentLoaded', function () {
    var canvas = document.getElementById('salesChart');
    if (canvas) {
        var ctx = canvas.getContext('2d');
        var myChart = new Chart(ctx, {
            type: 'bar', // or your desired chart type
            data: {
                labels: ["2016", "2017", "2018", "2019", "2020"],
                datasets: [{
                    label: 'Worldwide Sales',
                    data: [15, 30, 45, 60, 75],
                    backgroundColor: 'rgba(0, 123, 255, 0.5)',
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
            }
        });
    } else {
        console.error('Canvas element not found');
    }
});
