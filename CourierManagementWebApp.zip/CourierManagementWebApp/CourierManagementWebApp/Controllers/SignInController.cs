﻿using CourierManagementWebApp.Data;
using CourierManagementWebApp.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CourierManagementWebApp.Controllers
{
    public class SignInController : Controller
    {
        private readonly CourierDbContext _context;

        // Constructor to inject the CourierDbContext
        public SignInController(CourierDbContext context)
        {
            _context = context;
        }

        // GET: SignIn
        [HttpGet]
        public IActionResult SignIn()
        {
            return View();
        }

        // POST: SignIn
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SignIn([Bind("UserName,Password")] SignIn model)
        {
            if (ModelState.IsValid)
            {
                // Retrieve the user from the database based on the username
                var user = await _context.SignUps
                                          .FirstOrDefaultAsync(u => u.UserName == model.UserName);

                // If user exists and password matches, proceed with login
                if (user != null && VerifyPassword(model.Password, user.Password))
                {
                    // Store user info in TempData or Session (e.g., username)
                    TempData["UserName"] = user.UserName;

                    // Redirect to the home page or dashboard
                    return RedirectToAction("Home", "Index");
                }

                // Add an error message if invalid username or password
                ModelState.AddModelError(string.Empty, "Invalid username or password.");
            }

            // Return the view with validation errors
            return View(model);
        }

        // Method to verify the password (replace with proper logic for hashing)
        private bool VerifyPassword(string enteredPassword, string storedPassword)
        {
            // Implement password verification logic (e.g., hash comparison)
            return enteredPassword == storedPassword;  // Simplified for illustration
            // For production, use hashing, e.g., BCrypt
            // return BCrypt.Net.BCrypt.Verify(enteredPassword, storedPassword);
        }
    }
}
