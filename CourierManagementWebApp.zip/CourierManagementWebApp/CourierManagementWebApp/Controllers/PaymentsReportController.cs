﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using CourierManagementWebApp.Data;
using CourierManagementWebApp.Models;

namespace CourierManagementWebApp.Controllers
{
    public class PaymentsReportController : Controller
    {
        private readonly CourierDbContext _context;

        public PaymentsReportController(CourierDbContext context)
        {
            _context = context;
        }

        // GET: PaymentsReport
        public async Task<IActionResult> Index()
        {
            var courierDbContext = _context.T_Payment.Include(p => p.Shipments);
            return View(await courierDbContext.ToListAsync());
        }

        // GET: PaymentsReport/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var payment = await _context.T_Payment
                .Include(p => p.Shipments)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (payment == null)
            {
                return NotFound();
            }

            return View(payment);
        }

        // GET: PaymentsReport/Create
        public IActionResult Create()
        {
            ViewData["ShipmentId"] = new SelectList(_context.T_Shipment, "Id", "Id");
            return View();
        }

        // POST: PaymentsReport/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,ShipmentId,Amount,paymentDate")] Payment payment)
        {
            if (ModelState.IsValid)
            {
                _context.Add(payment);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["ShipmentId"] = new SelectList(_context.T_Shipment, "Id", "Id", payment.ShipmentId);
            return View(payment);
        }

        // GET: PaymentsReport/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var payment = await _context.T_Payment.FindAsync(id);
            if (payment == null)
            {
                return NotFound();
            }
            ViewData["ShipmentId"] = new SelectList(_context.T_Shipment, "Id", "Id", payment.ShipmentId);
            return View(payment);
        }

        // POST: PaymentsReport/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,ShipmentId,Amount,paymentDate")] Payment payment)
        {
            if (id != payment.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(payment);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!PaymentExists(payment.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["ShipmentId"] = new SelectList(_context.T_Shipment, "Id", "Id", payment.ShipmentId);
            return View(payment);
        }

        // GET: PaymentsReport/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var payment = await _context.T_Payment
                .Include(p => p.Shipments)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (payment == null)
            {
                return NotFound();
            }

            return View(payment);
        }

        // POST: PaymentsReport/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var payment = await _context.T_Payment.FindAsync(id);
            if (payment != null)
            {
                _context.T_Payment.Remove(payment);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool PaymentExists(int id)
        {
            return _context.T_Payment.Any(e => e.Id == id);
        }
    }
}
