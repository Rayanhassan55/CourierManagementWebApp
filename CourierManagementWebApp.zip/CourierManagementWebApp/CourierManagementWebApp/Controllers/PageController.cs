﻿using Microsoft.AspNetCore.Mvc;

namespace CourierManagementWebApp.Controllers
{
    public class PageController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
