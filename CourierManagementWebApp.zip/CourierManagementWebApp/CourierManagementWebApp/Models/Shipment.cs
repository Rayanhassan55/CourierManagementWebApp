﻿namespace CourierManagementWebApp.Models
{
    public class Shipment
    {
        public int Id { get; set; }
        public int CourierId { get; set; }
        public int CustomerId { get; set; }
        public int AddressId { get; set; }
        public DateTime ShipmentDate { get; set; }
        public string? Status { get; set; }
        public Courier? Courier { get; set; }
        public Customer? Customer { get; set; }
        public Address? Address { get; set; }
    }
}
